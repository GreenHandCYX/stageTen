export { default } from './src/tab-item.vue';
