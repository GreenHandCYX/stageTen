import Lazyload from 'vue-lazyload';
import 'mint-ui/src/style/empty.css';

export default Lazyload;
