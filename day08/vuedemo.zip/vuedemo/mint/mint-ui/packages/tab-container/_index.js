export default {
  TabContainer: require('./src/tab-container.vue'),
  TabContainerItem: require('../tab-container-item/src/tab-container-item.vue')
};
